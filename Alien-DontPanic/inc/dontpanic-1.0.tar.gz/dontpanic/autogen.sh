#!/bin/sh
autoreconf --force --install -I config -I m4
