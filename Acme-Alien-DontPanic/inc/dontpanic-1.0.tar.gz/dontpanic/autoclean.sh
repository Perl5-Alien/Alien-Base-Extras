make clean;
rm aclocal.m4 config.* configure Makefile Makefile.in stamp-h1 src/Makefile src/Makefile.in;
rm -Rf autom4te.cache libtool;
rm -Rf m4/* config/* src/.deps;

